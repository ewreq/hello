#!/sbin/sh
RIRU_PATH="/data/adb/riru"

rm "$RIRU_PATH/util_functions.sh"
rm "$RIRU_PATH/api_version"